#ifndef __RENDERTOMOVIE_H__BAAC02A1_7345_427e_A1E3_BF1B77BF1224_
#define __RENDERTOMOVIE_H__BAAC02A1_7345_427e_A1E3_BF1B77BF1224_

#include "AviFile.h"
#include "RenderTarget.h"

/// <Summary>
/// Creates a Movie from the DirectX Rendering Surface.
/// Movie Frame's Width and Height can not be changed once the Movie file is Created.
/// Any number of objects of this class can be present simultaneously with in single app.
/// </Summary>
class CDxToMovie
{
	CAviFile m_MovieFile;			/*The Movie File Object*/

	CRenderTarget m_RenderTarget;	/*The Render Target to Capture the DirectX Rendering*/

	int		m_nWidth;				/*Frame Width*/
	int		m_nHeight;				/*Frame Height*/
	int		m_nBitsPerPixel;		/*Number of Bits Per Pixel*/

	HBITMAP m_hBitmap;				/*Bitmap to read the surface content to*/
	LPVOID	m_pBitmapBits;			/*Pointer to the bitmap bits*/

public:

	CDxToMovie(LPCTSTR lpszOutputMovieFileName = _T("Output.avi"),	/*Output Movie File Name*/
		int nFrameWidth = GetSystemMetrics(SM_CXSCREEN),	/*Movie Frame Width*/
		int nFrameHeight = GetSystemMetrics(SM_CYSCREEN),	/*Movie Frame Height*/
		int nBitsPerPixel = 32,								/*Bits Per Pixel*/
		DWORD dwCodec = mmioFOURCC('M','P','G','4'),		/*Video Codec that should be used for Compression*/
		DWORD dwFrameRate = 1)								/*Frame Rate (FPS) setting for the Movie*/
		: m_MovieFile(lpszOutputMovieFileName, dwCodec, dwFrameRate)
	{
		m_nWidth		= nFrameWidth;
		m_nHeight		= nFrameHeight;
		m_nBitsPerPixel	= nBitsPerPixel;
        m_hBitmap		= NULL;
		m_pBitmapBits	= NULL;
	}

	~CDxToMovie(void)
	{
	}

	/// <Summary>Should be called when the device is created</Summary>
	inline HRESULT OnCreateDevice(LPDIRECT3DDEVICE9 pd3dDevice)
	{
		if(m_hBitmap == NULL)	/*Create the Bitmap*/
		{
			BITMAPINFO	bmpInfo;
			ZeroMemory(&bmpInfo,sizeof(bmpInfo));
			bmpInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			bmpInfo.bmiHeader.biBitCount= m_nBitsPerPixel;
			bmpInfo.bmiHeader.biCompression = BI_RGB;
			bmpInfo.bmiHeader.biPlanes = 1;
			bmpInfo.bmiHeader.biWidth = m_nWidth;
			bmpInfo.bmiHeader.biHeight = m_nHeight;
			bmpInfo.bmiHeader.biSizeImage = abs(bmpInfo.bmiHeader.biHeight)*abs(bmpInfo.bmiHeader.biWidth)*bmpInfo.bmiHeader.biBitCount/8;

			HDC hdc= GetDC(NULL);
			m_hBitmap = CreateDIBSection(hdc,&bmpInfo,DIB_RGB_COLORS,&m_pBitmapBits,NULL,NULL);
			ReleaseDC(NULL,hdc);
		}

		return m_RenderTarget.OnCreateDevice(pd3dDevice);
	}

	/// <Summary>Should be called when the device is being Destroyed</Summary>
	inline HRESULT OnDestroyDevice(LPDIRECT3DDEVICE9 pd3dDevice)
	{
		if(m_hBitmap) 
		{
			DeleteObject(m_hBitmap);
			m_hBitmap = NULL;
		}
		
		return m_RenderTarget.OnDestroyDevice(pd3dDevice);
	}

	/// <Summary>Should be called when the device is Lost</Summary>
	inline HRESULT OnLostDevice()
	{
        return m_RenderTarget.OnLostDevice();
	}

	/// <Summary>Should be called when the device is being Reset</Summary>
	inline HRESULT OnResetDevice(LPDIRECT3DDEVICE9 pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc)
	{
		return m_RenderTarget.OnResetDevice(pd3dDevice, pBackBufferSurfaceDesc);
	}

	/// <Summary>
	/// Starts a new Frame in the Movie (would not erase previous Frames).
	/// Should be called after IDirect3DDevice9::BeginScene() for each rendered frame.
	/// </Summary>
	inline HRESULT StartRecordingMovie(LPDIRECT3DDEVICE9 pd3dDevice)	
	{
		return m_RenderTarget.BeginCapture(pd3dDevice);
	}

	/// <Summary>
	/// Completes drawing the present Frame and inserts it into the Movie.
	/// Should be called before IDirect3DDevice9::EndScene() for each rendered frame.
	/// </Summary>
	inline HRESULT PauseRecordingMovie(LPDIRECT3DDEVICE9 pd3dDevice)
	{
		m_RenderTarget.EndCapture(pd3dDevice);
		m_RenderTarget.GetSurfaceBits(pd3dDevice, m_pBitmapBits);
		return m_MovieFile.AppendNewFrame(m_nWidth, m_nHeight, m_pBitmapBits, m_nBitsPerPixel);
	}

	inline const LPDIRECT3DSURFACE9 RecordingSurface() const {	return m_RenderTarget;	}

	inline const CAviFile* MovieFile() const	{	return &m_MovieFile;	}
};

#endif