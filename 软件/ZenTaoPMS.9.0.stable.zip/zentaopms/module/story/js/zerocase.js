$(document).ready(function()
{
    $('#zerocaseTab').addClass('active');
    fixedTfootAction('#productStoryForm');
    fixedTheadOfList('#storyList');
});
