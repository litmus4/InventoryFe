// BufferMovie.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "BufferMovie.h"
#include "DxToMovie.h"

#define		MAX_LOADSTRING	100
#define		ErrorMessage(x)	MessageBox(NULL,x,"Error",MB_OK|MB_ICONERROR)
#define		SCALEDOWNFACTOR	8.0f

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

IDirect3D9*				g_pD3D=NULL;
IDirect3DDevice9*		g_pd3dDevice=NULL;
IDirect3DVertexBuffer9*	g_pVB=NULL;

struct CUSTOMVERTEX
{
	float		x,y,z,rhw;
    D3DCOLOR	color;
};

#define D3DFVF_CUSTOMVERTEX	(D3DFVF_XYZRHW |D3DFVF_DIFFUSE)

HRESULT		InitD3D(HWND hWnd);
HRESULT		Reset(HWND hWnd,bool bReset = true);
void		Render(HWND hWnd);
void		Cleanup();
RECT		gClientRect;

///////////////////////////////////////////////////////////////
/// Create the Movie Recorder Object
///
CDxToMovie	g_MovieRecorder(_T("Output.avi"),320,240,32,mmioFOURCC('M','S','V','C'), 10);	// Use MSVC Codec with 10 FPS

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;
	HACCEL hAccelTable;

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_BUFFERMOVIE, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_BUFFERMOVIE);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_BUFFERMOVIE);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= NULL;//(HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCTSTR)IDC_BUFFERMOVIE;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_POPUPWINDOW|WS_VISIBLE|WS_CAPTION,
      CW_USEDEFAULT,CW_USEDEFAULT,gClientRect.right = 320, gClientRect.bottom=240, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch (message) 
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_CREATE:
		{
			LRESULT lRet = DefWindowProc(hWnd,message,wParam,lParam);
			if(lRet < 0)	
				return lRet;
			if(FAILED(InitD3D(hWnd)))	/*Initialize the Direct3D*/
				return -1;
			return lRet;
		}
	case WM_PAINT:
		{
			Render(hWnd);	/*Render the Required Animation*/
			ValidateRect(hWnd,NULL);
			break;
		}
	case WM_SIZE:
		{
			D3DXMATRIX		mat;
			gClientRect.right=LOWORD(lParam);
			gClientRect.bottom=HIWORD(lParam);
			g_pd3dDevice->SetTransform(D3DTS_PROJECTION,D3DXMatrixOrthoOffCenterLH(&mat,0,(float)gClientRect.right,0,(float)gClientRect.bottom,0,1));
			InvalidateRect(hWnd,NULL,false);
			break;
		}
	case WM_MOUSEMOVE:
		{
			D3DXMATRIX mat;
			CUSTOMVERTEX	*pVertices=NULL;
			float	x	=	(float)LOWORD(lParam);
			float	y	=	(float)HIWORD(lParam);

			if(FAILED(g_pVB->Lock(0,sizeof(CUSTOMVERTEX)*3,(void**)&pVertices,0)))
			{
				ErrorMessage("Unable to Lock the VertexBuffer");
				return E_FAIL;
			}

			pVertices[0].x	=	x;
			pVertices[0].y	=	y-25;
			pVertices[0].z	=	0.0f;
			pVertices[0].rhw=	1.0f;
			pVertices[1].x	=	x+25;
			pVertices[1].y	=	y+25;;
			pVertices[1].z	=	0.0f;
			pVertices[1].rhw=	1.0f;
			pVertices[2].x	=	x-25;
			pVertices[2].y	=	y+25;
			pVertices[2].z	=	0.0f;
			pVertices[2].rhw=	1.0f;
			pVertices[0].color	=	0xffffffff;
			pVertices[1].color	=	0xffffffff;
			pVertices[2].color	=	0xffffffff;

			g_pVB->Unlock();	
					
			InvalidateRect(hWnd,NULL,false);

			break;
		}
	case WM_DESTROY:
		{	
			Cleanup();
			PostQuitMessage(0);
			break;
		}
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
	return FALSE;
}

HRESULT InitD3D(HWND hWnd)
{
	if((g_pD3D=Direct3DCreate9(D3D_SDK_VERSION))==NULL)
	{
		ErrorMessage("Unable to Create Direct3D");
		return E_FAIL;
	}
	return Reset(hWnd,false);			//Create the Device
}

/// If bReset is set to false, then this function creates the device;
/// else,
/// this function Resets the device;
HRESULT Reset(HWND hWnd, bool bReset)
{
	D3DXMATRIX		mat;
	CUSTOMVERTEX*	pVertices;
	D3DDISPLAYMODE	d3ddm;
	D3DPRESENT_PARAMETERS	d3dpp;

	g_MovieRecorder.OnLostDevice();

	if(g_pVB)
	{
		g_pVB->Release();
		g_pVB = NULL;
	}
	if(FAILED(g_pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,&d3ddm)))
	{
		if(bReset==false)	ErrorMessage("Unable to Get Display Mode");
		return E_FAIL;
	}
	ZeroMemory(&d3dpp,sizeof(d3dpp));
	d3dpp.hDeviceWindow = hWnd;
	d3dpp.Windowed = true;
	d3dpp.BackBufferFormat = d3ddm.Format;
	d3dpp.BackBufferHeight = gClientRect.bottom;
	d3dpp.BackBufferWidth  = gClientRect.right;
	d3dpp.FullScreen_RefreshRateInHz = 0;
	d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
	d3dpp.SwapEffect	   = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferCount  = 1;
	d3dpp.Flags			   = 0;
	if(bReset == false)	//Create the Device
	{
		if(FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,hWnd,D3DCREATE_SOFTWARE_VERTEXPROCESSING,&d3dpp,&g_pd3dDevice)))
		{
			ErrorMessage("Unable to Create Direct3DDevice");
			return E_FAIL;
		}
		g_MovieRecorder.OnCreateDevice(g_pd3dDevice);
		D3DSURFACE_DESC desc;
		LPDIRECT3DSURFACE9 pBackSurface = NULL;
		g_pd3dDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackSurface);
		pBackSurface->GetDesc(&desc);
		pBackSurface->Release();
		g_MovieRecorder.OnResetDevice(g_pd3dDevice, &desc);
	}
	else	/*Reset the Device*/
	{
		if(FAILED(g_pd3dDevice->Reset(&d3dpp)))
			return E_FAIL;
		D3DSURFACE_DESC desc;
		LPDIRECT3DSURFACE9 pBackSurface = NULL;
		g_pd3dDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackSurface);
		pBackSurface->GetDesc(&desc);
		pBackSurface->Release();
		g_MovieRecorder.OnResetDevice(g_pd3dDevice, &desc);
	}
	if(FAILED(g_pd3dDevice->CreateVertexBuffer(sizeof(CUSTOMVERTEX)*3,0,D3DFVF_CUSTOMVERTEX,D3DPOOL_DEFAULT,&g_pVB,NULL)))
	{
		if(bReset == false)	ErrorMessage("Unable to Create Vertex Buffer");
		return E_FAIL;
	}
	if(FAILED(g_pVB->Lock(0,sizeof(CUSTOMVERTEX)*3,(void**)&pVertices,0)))
	{
		if(bReset == false)	ErrorMessage("Unable to Lock the VertexBuffer");
		return E_FAIL;
	}

	pVertices[0].x	=	gClientRect.right/2.0f;
	pVertices[0].y	=	gClientRect.bottom/2.0f-25;
	pVertices[0].z	=	0.0f;
	pVertices[0].rhw=	1.0f;
	pVertices[1].x	=	gClientRect.right/2.0f+25;
	pVertices[1].y	=	gClientRect.bottom/2.0f+25;
	pVertices[1].z	=	0.0f;
	pVertices[1].rhw=	1.0f;
	pVertices[2].x	=	gClientRect.right/2.0f-25;
	pVertices[2].y	=	gClientRect.bottom/2.0f+25;
	pVertices[2].z	=	0.0f;
	pVertices[2].rhw=	1.0f;
	pVertices[0].color	=	0xffffffff;
	pVertices[1].color	=	0xffffffff;
	pVertices[2].color	=	0xffffffff;

	g_pVB->Unlock();
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING,false);
	g_pd3dDevice->SetTransform(D3DTS_PROJECTION,D3DXMatrixOrthoOffCenterLH(&mat,0,(float)gClientRect.right,0,(float)gClientRect.bottom,0,1));
	return S_OK;
}

void Cleanup()
{
	g_MovieRecorder.OnLostDevice();
	g_MovieRecorder.OnDestroyDevice(g_pd3dDevice);

	if(g_pVB)
	{
		g_pVB->Release();
		g_pVB=NULL;
	}
	if(g_pd3dDevice)
	{
		g_pd3dDevice->Release();
		g_pd3dDevice =NULL;
	}
	if(g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D =NULL;
	}
}

void Render(HWND hWnd)
{
	IDirect3DSurface9*	pSurface=NULL;

	if(g_pd3dDevice == NULL)	return ;

	HRESULT	hr = g_pd3dDevice->TestCooperativeLevel();

	switch(hr)
	{
		case D3D_OK	:	break;
		case D3DERR_DEVICELOST:	return;
		case D3DERR_DEVICENOTRESET:	if(FAILED(Reset(hWnd)))	{	DestroyWindow(hWnd);	return;	}	break;
	}

	LPDIRECT3DSURFACE9 pBackSurface=NULL;

	g_pd3dDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&pBackSurface);

	g_pd3dDevice->BeginScene();

	g_MovieRecorder.StartRecordingMovie(g_pd3dDevice);	// Resume (Start) the recording
		g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(0,0,200),1,0);
		g_pd3dDevice->SetStreamSource(0,g_pVB,0,sizeof(CUSTOMVERTEX));
		g_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);
		g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST,0,1);	// Draw the Animation Primitives as usual
	g_MovieRecorder.PauseRecordingMovie(g_pd3dDevice);	// Pause the recording

	g_pd3dDevice->StretchRect(g_MovieRecorder.RecordingSurface(),NULL,pBackSurface,0,D3DTEXF_NONE);	//Copy the RenderTarget onto BackBuffer's Surface

	g_pd3dDevice->EndScene();

	g_pd3dDevice->Present(NULL,NULL,NULL,NULL);

	pBackSurface->Release();
}