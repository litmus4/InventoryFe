<?php
$lang->branch->common = '分支';
$lang->branch->manage = '分支管理';
$lang->branch->sort   = '排序';
$lang->branch->delete = '分支删除';

$lang->branch->manageTitle = '%s管理';
$lang->branch->all         = '所有';

$lang->branch->confirmDelete = '是否删除该@branch@？';
$lang->branch->canNotDelete  = '该@branch@下已经有数据，不能删除！';
