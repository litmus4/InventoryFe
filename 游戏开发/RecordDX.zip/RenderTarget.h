#ifndef __RENDERTARGET_H__284E72A6_C935_44f9_925E_FA31C3D96E33
#define __RENDERTARGET_H__284E72A6_C935_44f9_925E_FA31C3D96E33

class CRenderTarget
{
	LPDIRECT3DSURFACE9	m_pRenderTargetDepthBuffer;
	LPDIRECT3DSURFACE9	m_pRenderTarget;			//The Surface Onto which the scene would be Blit
	LPDIRECT3DTEXTURE9	m_pRenderTargetTexture;		//The Render Target is a Surface of this Texture
	LPDIRECT3DSURFACE9	m_pOffscreenPlainSurface;	//This is useful to get the render target data 

	LPDIRECT3DSURFACE9	m_pOldBackBuffer;			//Original back Buffer
	LPDIRECT3DSURFACE9	m_pOldDepthBuffer;			//Original Depth Buffer

	int			m_nWidth;
	int			m_nHeight;
	D3DFORMAT	m_Format;

	// Returns BitsPerPixel form D3DFORMAT
	inline int BPPFromD3DFormat(D3DFORMAT fmt)
	{
		switch(fmt)
		{
		case D3DFMT_A2R10G10B10: return 32;
		case D3DFMT_A8R8G8B8: return 32;
		case D3DFMT_X8R8G8B8: return 32;
		case D3DFMT_R8G8B8:	return 24;
		case D3DFMT_R5G6B5: return 16;
		case D3DFMT_X1R5G5B5: return 16;
		case D3DFMT_A1R5G5B5: return 16;
		case D3DFMT_A4R4G4B4: return 16;
		case D3DFMT_X4R4G4B4: return 16;
		default: return 0;
		}
	}

public:

	CRenderTarget(void)
	{
		m_nWidth = m_nHeight = 0;
		m_Format = D3DFMT_UNKNOWN;
		m_pRenderTarget = NULL;
		m_pOldBackBuffer = NULL;
		m_pOldDepthBuffer = NULL;
		m_pOffscreenPlainSurface = NULL;
		m_pRenderTargetDepthBuffer = NULL;
	}

	~CRenderTarget(void)
	{
	}

	/// <Summary>Should be calld when the device is Created</Summary>
	inline HRESULT OnCreateDevice(LPDIRECT3DDEVICE9 pd3dDevice)
	{
		return S_OK;
	}

	/// <Summary>Should be called when the device is being Reset</Summary>
	inline HRESULT OnResetDevice(LPDIRECT3DDEVICE9 pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc)
	{
		const D3DMULTISAMPLE_TYPE AA_TYPE = D3DMULTISAMPLE_NONE;
		const DWORD AA_QUALITY = 0;		//Should be Same for Depth buffer and RenderTargetSurface

		HRESULT hr = E_FAIL;
		m_nWidth = pBackBufferSurfaceDesc->Width;
		m_nHeight= pBackBufferSurfaceDesc->Height;
		m_Format = pBackBufferSurfaceDesc->Format;

		if(FAILED(hr = pd3dDevice->CreateDepthStencilSurface(m_nWidth, m_nHeight, D3DFMT_D16, AA_TYPE, AA_QUALITY, false, &m_pRenderTargetDepthBuffer, NULL)))
			return DXTRACE_ERR(_T("\n Unable to Create Depth Stencil Buffer"), hr);

		if(FAILED(hr = pd3dDevice->CreateTexture(m_nWidth, m_nHeight, 1, D3DUSAGE_RENDERTARGET, m_Format, D3DPOOL_DEFAULT, &m_pRenderTargetTexture, NULL)))
			return DXTRACE_ERR(_T("\n Unable to Create Render Target Texture"), hr);

		if(FAILED(hr = m_pRenderTargetTexture->GetSurfaceLevel(0, &m_pRenderTarget)))
			return DXTRACE_ERR(_T("\n Unable to Retrieve Render Target Texture Surface"), hr);

		if(FAILED(hr = pd3dDevice->CreateOffscreenPlainSurface(m_nWidth, m_nHeight, m_Format, D3DPOOL_SYSTEMMEM, &m_pOffscreenPlainSurface, NULL)))
			return DXTRACE_ERR(_T("\n Unable to Create Offscreen Plain Surface"), hr);

		if(FAILED(hr = pd3dDevice->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&m_pOldBackBuffer)))	//Save a Copy of Original Back Buffer Information
			return DXTRACE_ERR(_T("\n Unable to Get BackBuffer of the Device"), hr); 
	
		if(FAILED(hr = pd3dDevice->GetDepthStencilSurface(&m_pOldDepthBuffer)))
			return DXTRACE_ERR(_T("\n Unable to Get Depth Stencil Buffer"), hr);

		return S_OK;
	}

	/// <Summary>Should be called when the device is Lost</Summary>
	inline HRESULT OnLostDevice()
	{
		SAFE_RELEASE(m_pOffscreenPlainSurface);
		SAFE_RELEASE(m_pRenderTargetTexture);
		SAFE_RELEASE(m_pRenderTargetDepthBuffer);
		SAFE_RELEASE(m_pRenderTarget);
		SAFE_RELEASE(m_pOldBackBuffer);
		SAFE_RELEASE(m_pOldDepthBuffer);
		return S_OK;
	}

	/// <Summary>Should be called when the device is being Destroyed</Summary>
	inline HRESULT OnDestroyDevice(LPDIRECT3DDEVICE9 pd3dDevice)
	{
		return S_OK;
	}

	/// <Summary>
	/// Starts capturing all the drawing onto RenderTarget Suface till EndCapture() is called. 
	/// Should be called after IDirect3DDevice9::BeginScene().
	/// </Summary>
	HRESULT BeginCapture(LPDIRECT3DDEVICE9 pd3dDevice)	
	{
		pd3dDevice->SetRenderTarget(0, m_pRenderTarget);
		pd3dDevice->SetDepthStencilSurface(m_pRenderTargetDepthBuffer);
		return S_OK;
	}

	/// <Summary>
	/// Ends capturing the drawing onto the RenderTarget Surface.
	/// Should be called before IDirect3DDevice9::EndScene();
	/// </Summary>
	HRESULT EndCapture(LPDIRECT3DDEVICE9 pd3dDevice)
	{
		pd3dDevice->SetRenderTarget(0, m_pOldBackBuffer);
		pd3dDevice->SetDepthStencilSurface(m_pOldDepthBuffer);

		return S_OK;
	}

	inline operator LPDIRECT3DSURFACE9() const	{	return m_pRenderTarget;			}
	inline operator LPDIRECT3DTEXTURE9() const	{	return m_pRenderTargetTexture;	}

	inline const int Width() const	{	return m_nWidth;	}
	inline const int Height() const	{	return m_nHeight;	}
	inline const int Format() const	{	return m_Format;	}

	/// <Summary>
	/// Copies the content of the RenderTarget surface to the memory pointed to by pBits
	/// </Summary>
    HRESULT GetSurfaceBits(LPDIRECT3DDEVICE9 pd3dDevice, LPVOID pBits)
	{
		HRESULT hr;
		D3DLOCKED_RECT d3dSrcRect;        

		if(FAILED(hr = pd3dDevice->GetRenderTargetData(m_pRenderTarget, m_pOffscreenPlainSurface)))
			return DXTRACE_ERR(_T("\n Unable to Get Render Target Data"), hr);

		if(FAILED(hr = m_pOffscreenPlainSurface->LockRect(&d3dSrcRect,NULL,D3DLOCK_READONLY|D3DLOCK_NO_DIRTY_UPDATE)))			
			return DXTRACE_ERR(_T("Unable to Lock Render Target in GetSurfaceBits"),hr);
	    
		BYTE *pSrc	=	(BYTE*) d3dSrcRect.pBits;
		BYTE *pDest	=	(BYTE*)	pBits;
		int nBytesPerPixel = BPPFromD3DFormat(m_Format)/8;

		for(int i=0, nPitch=0, nRevPitch = (m_nHeight-1) * d3dSrcRect.Pitch; i< m_nHeight; i++, nPitch += d3dSrcRect.Pitch, nRevPitch -= d3dSrcRect.Pitch)
			memcpy(pDest + nRevPitch, pSrc + nPitch, m_nWidth * nBytesPerPixel);

		return m_pOffscreenPlainSurface->UnlockRect();
	}
};

#endif