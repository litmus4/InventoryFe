<?php
echo 'start from hello2.start.php<br>';
